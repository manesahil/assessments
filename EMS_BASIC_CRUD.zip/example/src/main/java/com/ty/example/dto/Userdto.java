package com.ty.example.dto;

public class Userdto {

	private String firstname;
	private String lastname;
	private String email;
	private int portno;

	public Userdto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Userdto(String firstname, String lastname, String email, int portno) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.portno = portno;
	}

	public String getfirstname() {
		return firstname;
	}

	public void setfirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getlastname() {
		return lastname;
	}

	public void setlastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getPortno() {
		return portno;
	}

	public void setPortno(int portno) {
		this.portno = portno;
	}

}
