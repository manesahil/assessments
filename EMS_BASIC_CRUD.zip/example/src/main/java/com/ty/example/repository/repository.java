package com.ty.example.repository;

import java.util.List;

import com.ty.example.dto.Userdto;
import com.ty.example.model.User;

public interface repository {

	public List<Userdto> viewall();

	public Userdto viewbyid(Long id);

	public void createEmp(User User);

	public int updateEmp(String email, Long id);

	public void updateEmpAny(Long id, User User);

	public void deleteEmp(Long id);
}
