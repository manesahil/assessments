package com.ty.example.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ty.example.dto.Userdto;
import com.ty.example.model.User;
import com.ty.example.model.userrowmapper;

@Repository
public class repositoryimpl implements repository {

	@Autowired
	private JdbcTemplate jdbctemplate;

	public List<Userdto> viewall() {
		String sql = "SELECT * FROM EMP";
		return jdbctemplate.query(sql, new userrowmapper());

	}

	public Userdto viewbyid(Long id) {
		String sql = "SELECT * FROM EMP WHERE ID=?";
		return jdbctemplate.queryForObject(sql, new Object[] { id }, new userrowmapper());
	}

	public void createEmp(User User) {
		String sql = "INSERT INTO emp (Firstname, Lastname, Email,portno) VALUES (?, ?, ?,?)";
		jdbctemplate.update(sql, User.getFirstname(), User.getLastname(), User.getEmail(), User.getPortno());
	}

	public int updateEmp(String email, Long id) {
		String sql = "UPDATE emp SET email=? WHERE id=?";
		return jdbctemplate.update(sql, email, id);
	}

	public void updateEmpAny(Long id, User User) {
		String sql = "UPDATE emp SET firstname=?,lastname=?,email=?,portno=? WHERE id=?";
		jdbctemplate.update(sql, User.getFirstname(), User.getLastname(), User.getEmail(), User.getPortno(), id);
	}

	public void deleteEmp(Long id) {
		String sql = "DELETE FROM emp where id=?";
		jdbctemplate.update(sql, id);
	}

}
